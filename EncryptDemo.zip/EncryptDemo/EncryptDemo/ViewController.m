//
//  ViewController.m
//  EncryptDemo
//
//  Created by Allison on 15/2/16.
//  Copyright (c) 2015年 Forrest. All rights reserved.
//

#import "ViewController.h"
#import "MacroUtils.h"
#import "FMDatabase.h"
#import "FMDatabaseQueue.h"
#import "FWMD5.h"
#import "AESCrypt.h"
#import "StringBase64.h"

@interface ViewController ()

@property (nonatomic, strong) NSString* dbPath;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.dbPath = [PATH_OF_DOCUMENT stringByAppendingPathComponent:@"user.sqlite"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - sql operations
- (IBAction)createTable:(id)sender
{
    debugMethod();
    NSFileManager* fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:self.dbPath] == NO) {
        // create it
        FMDatabase* db = [FMDatabase databaseWithPath:self.dbPath];
        if ([db open]) {
            NSString* sql = @"CREATE TABLE 'User' ('id' INTEGER PRIMARY KEY AUTOINCREMENT  NOT NULL , 'name' VARCHAR(30), 'password' VARCHAR(30))";
            BOOL res = [db executeUpdate:sql];
            if (!res) {
                debugLog(@"error when creating db table");
            }
            else {
                debugLog(@"succ to creating db table");
            }
            [db close];
        }
        else {
            debugLog(@"error when open db");
        }
    }
}

- (IBAction)insertData:(id)sender
{
    static int idx = 1;
    FMDatabase* db = [FMDatabase databaseWithPath:self.dbPath];
    if ([db open]) {
        NSString* sql = @"insert into user (name, password) values(?, ?) ";
        NSString* name = [NSString stringWithFormat:@"Row:%d", idx++];
        BOOL res = [db executeUpdate:sql, name, @"boy"];
        if (!res) {
            debugLog(@"error to insert data");
        }
        else {
            debugLog(@"succ to insert data");
        }
        [db close];
    }
}

- (IBAction)queryData:(id)sender
{
    debugMethod();
    FMDatabase* db = [FMDatabase databaseWithPath:self.dbPath];
    if ([db open]) {
        NSString* sql = @"select * from user";
        FMResultSet* rs = [db executeQuery:sql];
        while ([rs next]) {
            int userId = [rs intForColumn:@"id"];
            NSString* name = [rs stringForColumn:@"name"];
            NSString* pass = [rs stringForColumn:@"password"];
            debugLog(@"user id = %d, name = %@, pass = %@", userId, name, pass);
        }
        [db close];
    }
}

- (IBAction)clearAll:(id)sender
{
    FMDatabase* db = [FMDatabase databaseWithPath:self.dbPath];
    if ([db open]) {
        NSString* sql = @"delete from user";
        BOOL res = [db executeUpdate:sql];
        if (!res) {
            debugLog(@"error to delete db data");
        }
        else {
            debugLog(@"succ to deleta db data");
        }
        [db close];
    }
}

- (IBAction)multithread:(id)sender
{
    FMDatabaseQueue* queue = [FMDatabaseQueue databaseQueueWithPath:self.dbPath];
    dispatch_queue_t q1 = dispatch_queue_create("queue1", NULL);
    dispatch_queue_t q2 = dispatch_queue_create("queue2", NULL);

    dispatch_async(q1, ^{
        for (int i = 0; i < 100; ++i) {
            [queue inDatabase:^(FMDatabase *db) {
                NSString * sql = @"insert into user (name, password) values(?, ?) ";
                NSString * name = [NSString stringWithFormat:@"queue111 %d", i];
                BOOL res = [db executeUpdate:sql, name, @"boy"];
                if (!res) {
                    debugLog(@"error to add db data: %@", name);
                } else {
                    debugLog(@"succ to add db data: %@", name);
                }
            }];
        }
    });

    dispatch_async(q2, ^{
        for (int i = 0; i < 100; ++i) {
            [queue inDatabase:^(FMDatabase *db) {
                NSString * sql = @"insert into user (name, password) values(?, ?) ";
                NSString * name = [NSString stringWithFormat:@"queue222 %d", i];
                BOOL res = [db executeUpdate:sql, name, @"boy"];
                if (!res) {
                    debugLog(@"error to add db data: %@", name);
                } else {
                    debugLog(@"succ to add db data: %@", name);
                }
            }];
        }
    });
}

- (IBAction)runMD5:(id)sender
{
    NSString* password = @"hello Word";
    NSString* md5 = [FWMD5 md5HexDigest:password];
    NSLog(@"password:%@, md5:%@", password, md5);
}

//  AES加密
- (IBAction)runAES:(id)sender
{
    NSString* userName = @"User Name";
    NSString* password = @"hello Word";
    NSString* encryptedData = [AESCrypt encrypt:userName password:password]; //加密
    NSString* message = [AESCrypt decrypt:encryptedData password:password]; //解密
    NSLog(@"加密结果 = %@", encryptedData);
    NSLog(@"解密结果 = %@", message);
}

- (IBAction)runBase64:(id)sender
{
    NSString *string = @"需要加密的字符串";
    NSString *encodeString = StringToBASE64(string);;
    NSString *decodeString = Base64ToString(encodeString);
    NSLog(@"string:%@\n encodeString:%@\n decodeString:%@\n", string, encodeString, decodeString);
}

@end
