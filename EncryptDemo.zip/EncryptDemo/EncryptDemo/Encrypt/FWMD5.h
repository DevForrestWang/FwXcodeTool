//
//  CJMD5.h
//  FmdbTest
//
//  Created by forrest on 15/2/16.
//  Copyright (c) 2015年 forrest. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FWMD5 : NSObject

+ (NSString*)md5HexDigest:(NSString*)input;

@end
